﻿using Kentico.PageBuilder.Web.Mvc;
using MEDIOClinic.Controllers.Widgets;
using MEDIOClinic.Models.Widgets.TramWidget;
using Newtonsoft.Json;
using System;
using System.Net;
using System.Text;
using System.Web.Mvc;

[assembly: RegisterWidget("MatusU.Widgets.TramWidget", typeof(TramWidgetController), "DPMB Departures")]

namespace MEDIOClinic.Controllers.Widgets
{
    public class TramWidgetController : WidgetController<TramWidgetProperties>
    {
        private const string URL = "http://dpmbinfo.dpmb.cz/api/Departures";

        // GET: TramWidget
        public ActionResult Index()
        {
            // Get properties
            TramWidgetProperties properties = GetProperties();

            TramWidgetViewModel model = new TramWidgetViewModel();

            if (properties.StopID == 0)
            {
                model.DeparturesLoaded = false;
                model.ErrorMessage = "Please select the StopID from the widget configuration dialog.";
            } else
            {
                WebClient webClient = new WebClient();
                webClient.Encoding = Encoding.UTF8;

                try
                {
                    DPMBDeparturesModel dpmbDeparturesModel = new DPMBDeparturesModel();

                    string json = webClient.DownloadString(URL + "?stopid=" + properties.StopID);
                    dpmbDeparturesModel = JsonConvert.DeserializeObject<DPMBDeparturesModel>(json);
                    model.DeparturesLoaded = true;
                    model.Departures = dpmbDeparturesModel;
                }
                catch (Exception ex)
                {
                    model.DeparturesLoaded = false;
                    model.ErrorMessage = "There was an error while downloading the departures data.\n" + ex.Message;
                }
            }

            return PartialView("Widgets/_TramWidget", model);
        }
    }
}