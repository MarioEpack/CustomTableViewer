﻿using CMS.DataEngine;
using Kentico.Forms.Web.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace MEDIOClinic.FormBuilder
{
    public class StopSelectorComponentProperties : FormComponentProperties<int>
    {
        // Sets the component as the editing component of its DefaultValue property
        // System properties of the specified editing component, such as the Label, Tooltip, and Order, remain set to system defaults unless explicitly set in the constructor
        [DefaultValueEditingComponent("StopSelectorComponent", DefaultValue = 0)]
        public override int DefaultValue
        {
            get;
            set;
        }


        // Initializes a new instance of the RgbInputComponentProperties class and configures the underlying database field
        public StopSelectorComponentProperties()
            : base(FieldDataType.Integer)
        {
        }
    }
}