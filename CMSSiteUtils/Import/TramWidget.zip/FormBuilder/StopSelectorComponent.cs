﻿using Kentico.Forms.Web.Mvc;
using MEDIOClinic.FormBuilder;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

[assembly: RegisterFormComponent("StopSelectorComponent", typeof(StopSelectorComponent), "Stop selector", Description = "Allows to select a stop from the list", IconClass = "")]
namespace MEDIOClinic.FormBuilder
{
    public class StopSelectorComponent : FormComponent<StopSelectorComponentProperties, int>
    {
        private class StopModel
        {
            public int StopID { get; set; }
            public string Name { get; set; }
        }

        private List<SelectListItem> mItems;

        [BindableProperty]
        public int StopID { get; set; }

        public List<SelectListItem> Items {
            get {

                if (mItems == null || mItems.Count == 0)
                {
                    string jsonFile;

                    try
                    {
                        jsonFile = System.IO.File.ReadAllText(HttpContext.Current.Server.MapPath("~/Content/Widgets/TramWidget/stops.json"));
                        var stopItems = JsonConvert.DeserializeObject<List<StopModel>>(jsonFile);
                        mItems = new List<SelectListItem>();

                        foreach (StopModel stop in stopItems)
                        {
                            mItems.Add(new SelectListItem
                            {
                                Text = stop.Name,
                                Value = stop.StopID.ToString()
                            });
                        }
                    } catch (Exception ex)
                    {
                        var list = new List<SelectListItem>();
                        list.Add(new SelectListItem { Text = ex.Message, Value = "0" });

                        return list;
                    }
                }

                return mItems;
            } set {
                mItems = value;
            }
        }

        public override int GetValue()
        {
            return StopID;
        }

        public override void SetValue(int value)
        {
            StopID = value;
        }
    }
}