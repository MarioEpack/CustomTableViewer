﻿using System.Collections.Generic;

namespace MEDIOClinic.Models.Widgets.TramWidget
{
    public class DPMBDeparturesModel
    {
        public int StopID { get; set; }
        public List<DPMBPost> PostList { get; set; }
        public string Message { get; set; }
    }

    public class DPMBPost
    {
        public List<DPMBPostDeparture> Departures { get; set; }
        public string Name { get; set; }
        public int PostID { get; set; }
    }

    public class DPMBPostDeparture
    {
        public string FinalStop { get; set; }
        public bool IsLowFloor { get; set; }
        public string Line { get; set; }
        public string TimeMark { get; set; }
        public string Name { get; set; }
        public string Message { get; set; }
    }

    public class TramWidgetViewModel
    {
        public bool DeparturesLoaded { get; set; }
        public string ErrorMessage { get; set; }
        public DPMBDeparturesModel Departures { get; set; }
    }
}