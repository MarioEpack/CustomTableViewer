﻿using Kentico.Forms.Web.Mvc;
using Kentico.PageBuilder.Web.Mvc;

namespace MEDIOClinic.Models.Widgets.TramWidget
{
    public sealed class TramWidgetProperties : IWidgetProperties
    {
        [EditingComponent("StopSelectorComponent", Order = 0, Label = "Stop")]
        public int StopID { get; set; }


    }
}